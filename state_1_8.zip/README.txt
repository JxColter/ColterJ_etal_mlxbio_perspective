STATE evidence for agreement_analysis_1_8.py

Extract this archive into the project root. It creates Data/state_1_8.
No prior evidence folder is replaced.

Required inputs: text_values.csv, figure_values.csv, S1.csv, S2.csv, S3.csv.
text_values.csv contains paper-text extractions; value_kind distinguishes raw
scores, author-stated absolute improvements, and relative improvements.
figure_values.csv contains PARTIAL provisional OCR-consensus annotations.
OCR agreement is not independent visual verification. These annotations are
excluded from plots by default; --include-ocr opts in to provisional plots.
S1-S3 are metadata, not model-performance scores.
Source PDFs, page images, annotation audit, and source locators are included.
S9D curves have NOT been digitized. This is not a complete STATE score table.
